<div class="table">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>