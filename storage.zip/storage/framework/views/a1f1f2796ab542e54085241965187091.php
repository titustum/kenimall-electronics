 <!-- Navbar Section -->
 <nav class="bg-white shadow-md">
    <!-- Top Div for Social Media and Contact Info -->
    <div class="w-full bg-blue-600 text-white">
        <div class="container mx-auto flex justify-between items-center px-6 py-2">
            <!-- Social Media Links (Left) -->
            <div class="flex space-x-4">
                <a href="#" class="hover:text-blue-500"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="hover:text-blue-400"><i class="fab fa-twitter"></i></a>
                <a href="#" class="hover:text-pink-500"><i class="fab fa-instagram"></i></a>
                <a href="#" class="hover:text-red-500"><i class="fab fa-youtube"></i></a>
            </div>

            <!-- Contact Info (Right) -->
            <div class="flex space-x-6">
                <span class="text-sm">
                    <i class="fal fa-phone-alt"></i>
                    <span class="hidden md:inline">(123) 456-7890</span>
                </span>
                <span class="text-sm">
                    <i class="fal fa-envelope"></i>
                    <span class="hidden md:inline">contact@kamarona.com</span>
                </span>
            </div>
        </div>
    </div>

    <!-- Main Navbar Section -->
    <div class="container mx-auto flex items-center justify-between px-6 py-4">

        <!-- Logo Section -->
        <div class="flex items-center space-x-4 font-[Righteous]">
            <a href="#" class="text-gray-800 text-3xl flex items-center space-x-2">
                <i class="far fa-plug text-amber-500"></i>
                <span class="hidden md:inline">kamarona</span>
            </a>
        </div>

        <!-- Menu Section -->
        <div class="hidden lg:flex space-x-6">
            <a href="#home" class="text-gray-800 hover:text-yellow-300 transition duration-300">Home</a>
            <a href="#shop" class="text-gray-800 hover:text-yellow-300 transition duration-300">Shop</a>
            <a href="#deals" class="text-gray-800 hover:text-yellow-300 transition duration-300">Deals</a>
            <a href="#about" class="text-gray-800 hover:text-yellow-300 transition duration-300">About</a>
            <a href="#contact" class="text-gray-800 hover:text-yellow-300 transition duration-300">Contact</a>
        </div>

        <!-- Search Bar Section -->
        <form class="flex items-center space-x-4">
            <!-- Search Bar with Icon -->
            <div class="relative flex-grow">
                <input type="text" placeholder="Search products..."
                    class="px-4 py-2.5 rounded-lg bg-white border border-gray-200 focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200/40 placeholder:text-gray-400 text-gray-700 transition-all w-full md:w-72 pr-12">
                <!-- Search Icon -->
                <i class="far fa-search absolute right-4 top-1/2 transform -translate-y-1/2 text-amber-500/80"></i>
            </div>

            <!-- Cart Icon with Badge -->
            <a href="#cart" class="relative text-gray-600 hover:text-amber-600 transition-colors duration-200 ml-2">
                <i class="far fa-shopping-cart text-xl"></i>
                <span
                    class="absolute -top-1 -right-3 text-xs bg-amber-600 text-white rounded-full w-5 h-5 flex items-center justify-center shadow-sm border border-white">3</span>
            </a>

            <!-- User Profile Icon -->
            <a href="#profile" class="text-gray-600 hover:text-amber-600 transition-colors duration-200 ml-3">
                <i class="far fa-user text-xl"></i>
            </a>
        </form>



        <!-- Mobile Menu Icon -->
        <div class="lg:hidden flex items-center">
            <button id="mobile-menu-button" class="text-gray-800 ml-2">
                <i class="fas fa-bars text-2xl"></i>
            </button>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="md:hidden bg-white px-6 py-4 hidden">
        <a href="#home" class="block text-gray-800 py-2 hover:text-yellow-300">Home</a>
        <a href="#shop" class="block text-gray-800 py-2 hover:text-yellow-300">Shop</a>
        <a href="#deals" class="block text-gray-800 py-2 hover:text-yellow-300">Deals</a>
        <a href="#about" class="block text-gray-800 py-2 hover:text-yellow-300">About</a>
        <a href="#contact" class="block text-gray-800 py-2 hover:text-yellow-300">Contact</a>
    </div>
</nav>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/components/home/NavbarSection.blade.php ENDPATH**/ ?>