<?php if (isset($component)) { $__componentOriginal62f0572da10cb2e009b2958870a997e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62f0572da10cb2e009b2958870a997e5 = $attributes; } ?>
<?php $component = App\View\Components\CustomLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('custom-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CustomLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e(Str::limit($product->description, 160)); ?>">
    <meta name="keywords"
        content="<?php echo e($product->name); ?>, <?php echo e($product->model ?? ''); ?>, <?php echo e($product->category->name ?? ''); ?>">
    <meta property="og:title" content="<?php echo e($product->name); ?>">
    <meta property="og:description" content="<?php echo e(Str::limit($product->description, 160)); ?>">
    <meta property="og:image"
        content="<?php echo e(Storage::exists($product->image_path) ? Storage::url($product->image_path) : $product->image_path); ?>">
    <meta property="og:type" content="product">
    <meta property="product:price:amount" content="<?php echo e($product->sale_price ?? $product->price); ?>">
    <meta property="product:price:currency" content="AUD">
    <?php $__env->stopPush(); ?>

    
    <?php $__env->startPush('scripts'); ?>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": "<?php echo e($product->name); ?>",
            "description": "<?php echo e($product->description); ?>",
            "image": "<?php echo e(Storage::exists($product->image_path) ? Storage::url($product->image_path) : $product->image_path); ?>",
            "sku": "<?php echo e($product->sku ?? $product->id); ?>",
            "brand": {
                "@type": "Brand",
                "name": "<?php echo e($product->brand ?? config('app.name')); ?>"
            },
            "offers": {
                "@type": "Offer",
                "url": "<?php echo e(request()->url()); ?>",
                "priceCurrency": "AUD",
                "price": "<?php echo e($product->sale_price ?? $product->price); ?>",
                "availability": "<?php echo e($product->stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock'); ?>",
                "seller": {
                    "@type": "Organization",
                    "name": "<?php echo e(config('app.name')); ?>"
                }
            }
        }
    </script>
    <?php $__env->stopPush(); ?>

    <div class="max-w-7xl mx-auto px-4 py-8 mt-20">
        
        <nav class="mb-8 hidden lg:block" aria-label="Breadcrumb">
            <ol class="flex items-center space-x-2 text-sm text-gray-500">
                <li><a href="<?php echo e(route('home')); ?>" class="hover:text-orange-600 transition">Home</a></li>
                <li><span class="mx-2">/</span></li>
                <?php if($product->category): ?>
                <li><a href="#" class="hover:text-orange-600 transition"><?php echo e($product->category->name); ?></a></li>
                <li><span class="mx-2">/</span></li>
                <?php endif; ?>
                <li class="text-gray-900 font-medium hidden lg:inline" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
        </nav>

        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16" data-aos="fade-up">
            
            <div class="space-y-4">
                <?php
                $imageUrl = Storage::exists($product->image_path) ? 'storage/'.Storage::url($product->image_path) :
                $product->image_path;
                $additionalImages = $product->additional_images ? json_decode($product->additional_images, true) : [];
                ?>

                <div class="relative">
                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($product->name); ?>"
                        class="w-full h-96 lg:h-[500px] object-contain rounded-xl shadow-lg bg-white"
                        id="main-product-image" />

                    
                    

                    
                    <div class="absolute top-4 left-4">
                        <span
                            class="px-3 py-1 rounded-full text-sm font-medium <?php echo e($product->stock > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e($product->stock > 0 ? 'In Stock' : 'Out of Stock'); ?>

                        </span>
                    </div>
                </div>

                
                <?php if(count($additionalImages) > 0): ?>
                <div class="flex space-x-2 overflow-x-auto pb-2">
                    <button class="flex-shrink-0 w-16 h-16 rounded-lg border-2 border-orange-600 overflow-hidden"
                        onclick="changeMainImage('<?php echo e($imageUrl); ?>')">
                        <img src="<?php echo e($imageUrl); ?>" alt="Main view" class="w-full h-full object-contain">
                    </button>
                    <?php $__currentLoopData = $additionalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button
                        class="flex-shrink-0 w-16 h-16 rounded-lg border-2 border-gray-200 hover:border-orange-600 overflow-hidden transition"
                        onclick="changeMainImage('<?php echo e(Storage::url($image)); ?>')">
                        <img src="<?php echo e(Storage::url($image)); ?>" alt="View <?php echo e($index + 2); ?>"
                            class="w-full h-full object-contain">
                    </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>

            
            <div class="space-y-6">
                <div>
                    <h1 class="text-2xl lg:text-3xl font-bold text-gray-900 mb-2"><?php echo e($product->name); ?></h1>

                    <?php if($product->model): ?>
                    <p class="text-gray-600 mb-2">Model: <span class="font-medium"><?php echo e($product->model); ?></span></p>
                    <?php endif; ?>

                    <?php if($product->brand): ?>
                    <p class="text-gray-600">Brand: <span class="font-medium"><?php echo e($product->brand->name); ?></span></p>
                    <?php endif; ?>
                </div>

                
                <div class="border-t border-b border-gray-200 py-4">
                    <div class="flex items-center space-x-4">
                        <span class="text-3xl font-bold text-green-600">
                            $<?php echo e(number_format($product->sale_price ?? $product->price, 2)); ?>

                        </span>

                        <?php if($product->sale_price): ?>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl text-gray-400 line-through">
                                $<?php echo e(number_format($product->price, 2)); ?>

                            </span>
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm font-semibold">
                                Save <?php echo e(round((($product->price - $product->sale_price) / $product->price) * 100)); ?>%
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if($product->stock > 0 && $product->stock <= 10): ?> <p class="text-orange-600 text-sm mt-2">
                        <i class="fas fa-exclamation-triangle mr-1"></i>
                        Only <?php echo e($product->stock); ?> left in stock!
                        </p>
                        <?php endif; ?>
                </div>

                
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Description</h3>
                    <p class="text-gray-700 leading-relaxed"><?php echo e($product->description); ?></p>
                </div>

                
                <?php if($product->features): ?>
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-3">Key Features</h3>
                    <ul class="space-y-2">
                        <?php $__currentLoopData = json_decode($product->features, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-start space-x-2">
                            <i class="fas fa-check text-green-500 mt-1 flex-shrink-0"></i>
                            <span class="text-gray-700"><?php echo e($feature); ?></span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                
                <div class="space-y-4">
                    <?php if($product->stock > 0): ?>
                    <div class="flex space-x-3">
                        <div class="flex items-center border border-gray-300 rounded-lg">
                            <button type="button" class="px-3 py-2 text-gray-600 hover:text-gray-800 transition"
                                onclick="decreaseQuantity()">
                                <i class="fas fa-minus"></i>
                            </button>
                            <input type="number" id="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>"
                                class="w-16 text-center border-0 focus:ring-0 focus:outline-none">
                            <button type="button" class="px-3 py-2 text-gray-600 hover:text-gray-800 transition"
                                onclick="increaseQuantity()">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>

                        <button onclick="quickAddToCart(<?php echo e($product->id); ?>)"
                            class="flex-1 bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition font-medium">
                            <i class="fas fa-shopping-cart mr-2"></i>Add to Cart
                        </button>
                    </div>

                    <div class="flex space-x-3">
                        <button onclick="quickBuyNow(<?php echo e($product->id); ?>)"
                            class="flex-1 bg-gray-900 text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition font-medium">
                            <i class="fas fa-bolt mr-2"></i>Buy Now
                        </button>

                        <button onclick="toggleWishlist(<?php echo e($product->id); ?>)"
                            class="px-6 py-3 border border-orange-600 text-orange-600 rounded-lg hover:bg-orange-50 transition font-medium">
                            <i class="fas fa-heart mr-2"></i>Wishlist
                        </button>
                    </div>
                    <?php else: ?>
                    <div class="bg-gray-100 border border-gray-300 rounded-lg p-4 text-center">
                        <p class="text-gray-600 font-medium">This product is currently out of stock</p>
                        <button class="mt-2 text-orange-600 hover:text-orange-700 transition font-medium">
                            Notify when available
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                
                <div class="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-truck text-green-600"></i>
                        <span>Free shipping on orders over $50</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-undo text-blue-600"></i>
                        <span>30-day return policy</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-shield-alt text-orange-600"></i>
                        <span>1-year warranty included</span>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if($product->specifications): ?>
        <div class="mb-16" data-aos="fade-up" data-aos-delay="100">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
                    <h3 class="text-xl font-semibold text-gray-900">Technical Specifications</h3>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php $__currentLoopData = json_decode($product->specifications, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between py-2 border-b border-gray-100 last:border-b-0">
                            <span class="font-medium text-gray-700"><?php echo e(ucwords(str_replace('_', ' ', $spec))); ?>:</span>
                            <span class="text-gray-600"><?php echo e($value); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if($relatedProducts->count()): ?>
        <div data-aos="fade-up" data-aos-delay="200">
            <div class="flex items-center justify-between mb-8">
                <h2 class="text-2xl font-bold text-gray-900">You might also like</h2>
                <a href="<?php echo e(route('products.index')); ?>" class="text-orange-600 hover:text-orange-700 font-medium">
                    View all products <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $delay = 100; ?>

                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $relImage = Storage::exists($related->image_path) ? Storage::url($related->image_path) :
                $related->image_path;
                $relPrice = $related->sale_price ?? $related->price;
                $delay += 50;
                ?>

                <div data-aos="fade-up" data-aos-delay="<?php echo e($delay); ?>"
                    class="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group border border-gray-100">
                    <a href="<?php echo e(route('products.show', $related->slug)); ?>" class="block">
                        <div class="relative overflow-hidden">
                            <img src="<?php echo e($relImage); ?>" alt="<?php echo e($related->name); ?>"
                                class="w-full h-48 object-contain p-4 transition-transform duration-300 group-hover:scale-105">

                            <?php if($related->sale_price): ?>
                            <div
                                class="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">
                                SALE
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="p-4">
                            <h3
                                class="font-semibold text-gray-800 mb-2 line-clamp-2 group-hover:text-orange-600 transition">
                                <?php echo e($related->name); ?>

                            </h3>

                            <div class="flex items-center justify-between">
                                <div>
                                    <span class="text-lg font-bold text-orange-600">$<?php echo e(number_format($relPrice, 2)); ?></span>
                                    <?php if($related->sale_price): ?>
                                    <span class="text-sm text-gray-400 line-through ml-2">$<?php echo e(number_format($related->price, 2)); ?></span>
                                    <?php endif; ?>
                                </div>

                                <?php if($related->stock > 0): ?>
                                <button onclick="quickAddToCart(<?php echo e($related->id); ?>, event)"
                                    class="opacity-0 group-hover:opacity-100 transition-opacity bg-orange-600 text-white p-2 rounded-lg hover:bg-orange-700">
                                    <i class="fas fa-plus text-sm"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    
    <?php $__env->startPush('scripts'); ?>
    <script>
        function changeMainImage(imageUrl) {
                document.getElementById('main-product-image').src = imageUrl;
            }

            function increaseQuantity() {
                const input = document.getElementById('quantity');
                const max = parseInt(input.getAttribute('max'));
                const current = parseInt(input.value);
                if (current < max) {
                    input.value = current + 1;
                }
            }

            function decreaseQuantity() {
                const input = document.getElementById('quantity');
                const current = parseInt(input.value);
                if (current > 1) {
                    input.value = current - 1;
                }
            }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $attributes = $__attributesOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__attributesOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $component = $__componentOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__componentOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/products/view.blade.php ENDPATH**/ ?>