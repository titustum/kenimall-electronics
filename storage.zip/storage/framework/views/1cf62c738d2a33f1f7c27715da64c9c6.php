<?php echo e($slot); ?>

<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>