<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['categories'=>[]]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['categories'=>[]]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<!-- Shop by Categories Section -->
<section id="categories" class="py-16 bg-white">
    <div class="container mx-auto px-6 text-center">
        <!-- Section Title -->
        <h2 class="text-3xl md:text-4xl font-semibold text-gray-800 mb-12">
            Shop by Categories
        </h2>

        <!-- Categories Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="group relative rounded-lg overflow-hidden transform transition-all duration-300 hover:scale-105">
                <!-- Category Image -->
                <div class="p-2 md:p-6">
                    <a href="#" aria-label="<?php echo e($category->name); ?> Category" class="block">
                        <img src="<?php echo e($category->image_path); ?>" alt="<?php echo e($category->name); ?>"
                            class="w-full h-32 lg:h-48 object-contain transition-transform duration-500 group-hover:scale-110">
                    </a>
                </div>
                <!-- Category Name -->
                <a href="#" aria-label="Go to <?php echo e($category->name); ?> category"
                    class="block py-4 truncate w-full text-sm md:text-wrap font-medium text-gray-800 px-3 hover:text-blue-500 transition duration-200 rounded-b-lg">
                    <?php echo e($category->name); ?>

                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/components/home/shop-by-categories-section.blade.php ENDPATH**/ ?>