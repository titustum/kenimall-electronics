<?php if (isset($component)) { $__componentOriginal7e59af25d3f091ff3a3fa38f77f8a4fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e59af25d3f091ff3a3fa38f77f8a4fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.email-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.email-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php $__env->slot('title'); ?>
    Shipping Update for Order #<?php echo e($order->order_number); ?>

    <?php $__env->endSlot(); ?>

    
    <?php
    $color_primary = '#F97316'; // A vibrant orange for your brand
    $color_text_dark = '#374151'; // Dark grey for main text
    ?>

    <h1 style="font-size: 28px; text-align: center; margin-bottom: 25px; color: <?php echo e($color_primary); ?>;">
        Your Order Has BeenShipped!
    </h1>

    <p style="text-align: center; font-size: 18px; line-height: 1.5;">
        Fantastic news, <b><?php echo e($order->name); ?></b>! Your order <b>#<?php echo e($order->order_number); ?></b> is now on its way to
        you.
    </p>

    <div class="panel">
        <h2 style="font-size: 20px; color: <?php echo e($color_primary); ?>; margin-bottom: 15px;">Shipping Details</h2>
        <ul style="list-style: none; padding: 0; margin: 0; line-height: 1.6;">
            <li style="margin-bottom: 8px;"><strong>Order Number:</strong> <strong
                    style="color: <?php echo e($color_primary); ?>;"><?php echo e($order->order_number); ?></strong></li>
            <li style="margin-bottom: 8px;"><strong>Tracking Number:</strong> <span
                    style="font-weight: bold; color: <?php echo e($color_text_dark); ?>;"><?php echo e($trackingNumber); ?></span></li>
            <li style="margin-bottom: 8px;"><strong>Carrier:</strong> <?php echo e($carrierName); ?></li>
            <li style="margin-bottom: 8px;">
                <strong>Shipping Address:</strong>
                <br><?php echo e($order->address); ?>

                <br><?php echo e($order->suburb); ?>, <?php echo e($order->state); ?> <?php echo e($order->postcode); ?>

                <br><?php echo e($order->country); ?>

            </li>
            <?php if($order->phone): ?> 
            <li style="margin-bottom: 8px;"><strong>Contact Phone:</strong> <?php echo e($order->phone); ?></li>
            <?php endif; ?>
        </ul>

        <p style="text-align: center; margin-top: 20px;">
            You can track your package directly using the link below:
        </p>

        <p style="text-align: center;">
            <a href="<?php echo e($trackingUrl); ?>" class="button" style="background-color: #e66200" target="_blank">Track Your
                Package</a>
        </p>
    </div>

    <p style="text-align: center; margin-top: 25px;">
        We'll keep you updated if there are any significant changes to your delivery.
    </p>

    <p style="text-align: center; margin-top: 25px;">
        If you have any questions, please don't hesitate to reach out to our support team.
    </p>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e59af25d3f091ff3a3fa38f77f8a4fd)): ?>
<?php $attributes = $__attributesOriginal7e59af25d3f091ff3a3fa38f77f8a4fd; ?>
<?php unset($__attributesOriginal7e59af25d3f091ff3a3fa38f77f8a4fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e59af25d3f091ff3a3fa38f77f8a4fd)): ?>
<?php $component = $__componentOriginal7e59af25d3f091ff3a3fa38f77f8a4fd; ?>
<?php unset($__componentOriginal7e59af25d3f091ff3a3fa38f77f8a4fd); ?>
<?php endif; ?><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/emails/shipping/confirmation.blade.php ENDPATH**/ ?>