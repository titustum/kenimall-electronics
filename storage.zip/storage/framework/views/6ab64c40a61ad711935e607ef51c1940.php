<div class="table">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/table.blade.php ENDPATH**/ ?>