<?php if (isset($component)) { $__componentOriginal13e16c1e8ce053aa0f0945cd3d4db948 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13e16c1e8ce053aa0f0945cd3d4db948 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.custom','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.custom'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-6 container mx-auto">
        <div class="bg-white max-w-6xl w-full p-6 relative">
            
            <!-- Product Details -->
            <div class="flex flex-col md:flex-row">
                <!-- Product Image -->
                <div class="w-full md:w-1/3">
                    <img src="<?php echo e($product ? $product->image_path : ''); ?>" alt="<?php echo e($product ? $product->name : ''); ?>" class="w-full h-auto object-contain">
                </div>
                <!-- Product Info -->
                <div class="w-full md:w-2/3 md:pl-6 mt-4 md:mt-0">
                    <h3 class="text-xl font-semibold text-gray-800"><?php echo e($product ? $product->name : ''); ?></h3>
                    <p class="text-gray-500 mt-2"><?php echo e($product && $product->description ? $product->description : 'No description available.'); ?></p>
                    
                    <!-- Rating Stars -->
                    <div class="flex items-center my-3">
                        <div class="flex text-amber-400">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <span>
                                    <?php if($product && $i <= floor($product->rating)): ?>
                                        <i class="fas fa-star"></i>
                                    <?php elseif($product && $i - 0.5 <= $product->rating): ?>
                                        <i class="fas fa-star-half-alt"></i>
                                    <?php else: ?>
                                        <i class="far fa-star"></i>
                                    <?php endif; ?>
                                </span>
                            <?php endfor; ?>
                        </div>
                        <span class="text-xs text-gray-500 ml-2"><?php echo e($product ? "({$product->reviews_count} reviews)" : ''); ?></span>
                    </div>
                    
                    <!-- Price -->
                    <div>
                        <?php if($product && $product->original_price): ?>
                            <span class="text-sm text-gray-500 line-through mr-2"><?php echo e('$' . number_format($product->original_price, 2)); ?></span>
                        <?php endif; ?>
                        <span class="text-xl font-bold text-gray-800"><?php echo e($product ? '$' . number_format($product->price, 2) : ''); ?></span>
                    </div>
    
                    <!-- Product Specs -->
                    <div class="mt-4 text-gray-700">
                        <p><strong>Brand:</strong> <span><?php echo e($product ? $product->brand : ''); ?></span></p>
                        <p><strong>Model:</strong> <span><?php echo e($product && $product->model ? $product->model : ''); ?></span></p>
                        <p><strong>Processor:</strong> <span><?php echo e($product ? $product->processor : ''); ?></span></p>
                        <p><strong>RAM:</strong> <span><?php echo e($product ? $product->ram : ''); ?></span></p>
                        <p><strong>Storage:</strong> <span><?php echo e($product ? $product->storage : ''); ?></span></p>
                    </div>
    
                    <div class="flex mt-6 space-x-4">
                        <a href="#"
                           class="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium text-sm transition-colors duration-200 shadow-sm">
                           <i class="far fa-shopping-cart"></i> Add to Cart
                        </a>
                        <a href="#"
                           class="bg-blue-50 hover:bg-blue-100 text-blue-800 py-2 px-4 rounded-lg font-medium text-sm transition-colors duration-200">
                            <i class="far fa-heart"></i> Favorite
                        </a>
                    </div>
                </div>
            </div>

           

            <!-- Product Features -->
            <div class="mt-8">
                <h4 class="text-2xl font-semibold text-gray-800">Features</h4>
                <ul class="list-disc pl-6 mt-2 text-gray-700">
                    <?php if($product->features): ?>
                        <?php
                            $features = json_decode($product->features, true); // Decode to an array
                        ?>
                        
                        <?php if($features): ?>
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featureKey => $featureValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($featureKey); ?>: <?php echo e($featureValue); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                </ul>
            </div>

            <!-- Customer Reviews Section -->
            


          

             
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal631726c9edc5c6f68f88858ccd9f438f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal631726c9edc5c6f68f88858ccd9f438f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home.footer-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home.footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal631726c9edc5c6f68f88858ccd9f438f)): ?>
<?php $attributes = $__attributesOriginal631726c9edc5c6f68f88858ccd9f438f; ?>
<?php unset($__attributesOriginal631726c9edc5c6f68f88858ccd9f438f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal631726c9edc5c6f68f88858ccd9f438f)): ?>
<?php $component = $__componentOriginal631726c9edc5c6f68f88858ccd9f438f; ?>
<?php unset($__componentOriginal631726c9edc5c6f68f88858ccd9f438f); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13e16c1e8ce053aa0f0945cd3d4db948)): ?>
<?php $attributes = $__attributesOriginal13e16c1e8ce053aa0f0945cd3d4db948; ?>
<?php unset($__attributesOriginal13e16c1e8ce053aa0f0945cd3d4db948); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13e16c1e8ce053aa0f0945cd3d4db948)): ?>
<?php $component = $__componentOriginal13e16c1e8ce053aa0f0945cd3d4db948; ?>
<?php unset($__componentOriginal13e16c1e8ce053aa0f0945cd3d4db948); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/product/view.blade.php ENDPATH**/ ?>