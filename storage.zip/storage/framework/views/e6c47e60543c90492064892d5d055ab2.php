 <!-- Hero Section -->
 <section class="relative h-[500px] md:h-[700px]">
    <!-- Video Background -->
    <video autoplay loop muted class="absolute inset-0 w-full h-full object-cover">
        <source src="https://v.ftcdn.net/09/13/40/66/700_F_913406609_bQ0tZ8gAbf7BJXvQxvPR3wEF9AV7dbNm_ST.mp4"
            type="video/mp4">
    </video>

    <!-- Dark Overlay to make text stand out -->
    <div class="absolute inset-0 bg-black opacity-60"></div>

    <!-- Content inside the hero section -->
    <div class="container mx-auto h-full flex justify-center items-center relative text-center text-white px-6">
        <div class="space-y-4">
            <!-- Headline -->
            <h1 class="text-4xl md:text-6xl font-extrabold leading-tight">
                Welcome to Kamarona
            </h1>
            <!-- Subheading -->
            <p class="text-lg md:text-2xl">
                Discover the best electronics at unbeatable prices.
            </p>
            <!-- CTA Buttons: Shop Now & Search -->
            <div class="flex justify-center space-x-4 mt-6"> 
                
                <!-- Search Bar and Button -->
                <div class="flex items-center space-x-2">
                    <input type="text" id="search" placeholder="Search products..." autofocus="true"hhhaha
                        class="px-4 py-2 rounded-full border-2 bg-white border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-500 w-60 md:w-80 text-gray-800 placeholder-gray-400">
                    <button class="bg-yellow-500 text-gray-800 py-2 px-6 rounded-full text-lg font-semibold hover:bg-yellow-600 transition duration-300 flex items-center space-x-2">
                        <!-- FontAwesome search icon -->
                        <i class="far fa-search"></i>
                        <span>Search</span>
                    </button>
                </div>
            </div>
        </div>
    </div>


</section>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/components/home/HeroSection.blade.php ENDPATH**/ ?>