<?php if (isset($component)) { $__componentOriginal62f0572da10cb2e009b2958870a997e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62f0572da10cb2e009b2958870a997e5 = $attributes; } ?>
<?php $component = App\View\Components\CustomLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('custom-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CustomLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="py-12 mt-20 bg-white" data-aos="fade-up">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Shop by Category</h2>
                <p class="text-md text-gray-600 max-w-xl mx-auto">Browse our top categories and discover great products.
                </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $imageUrl = Storage::exists($category->image_path)
                ? Storage::url($category->image_path)
                : $category->image_path;
                $delay = $index * 75;
                ?>

                <a href="<?php echo e(route('products.index', ['category' => $category])); ?>"
                    class="group bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col items-center text-center hover:shadow-md transition"
                    data-aos="fade-up" data-aos-delay="<?php echo e($delay); ?>">
                    <div class="w-full h-36 overflow-hidden rounded-lg mb-3">
                        <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($category->name); ?>"
                            class="w-full h-full object-contain group-hover:scale-105 transition duration-300">
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 group-hover:text-orange-600">
                        <?php echo e($category->name); ?>

                    </h3>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="text-center mt-10" data-aos="fade-up" data-aos-delay="800">
                <a href="<?php echo e(route('products.index')); ?>"
                    class="inline-block px-6 py-3 bg-orange-600 text-white rounded-full text-sm font-medium hover:bg-orange-700 transition">
                    <i class="fas fa-store mr-1"></i> Browse All Products
                </a>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $attributes = $__attributesOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__attributesOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $component = $__componentOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__componentOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/categories/index.blade.php ENDPATH**/ ?>