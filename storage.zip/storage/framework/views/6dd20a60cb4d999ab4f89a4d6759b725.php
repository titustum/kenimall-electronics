
<ui-menu-radio-group <?php echo e($attributes); ?> data-flux-menu-radio-group>
    <?php echo e($slot); ?>

</ui-menu-radio-group>
<?php /**PATH F:\Projects\Laravel12\kamarona-electronics\vendor\livewire\flux\src/../stubs/resources/views/flux/menu/radio/group.blade.php ENDPATH**/ ?>