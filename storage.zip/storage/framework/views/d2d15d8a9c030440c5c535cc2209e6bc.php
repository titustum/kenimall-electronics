<?php if (isset($component)) { $__componentOriginal62f0572da10cb2e009b2958870a997e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62f0572da10cb2e009b2958870a997e5 = $attributes; } ?>
<?php $component = App\View\Components\CustomLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('custom-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CustomLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="bg-gray-50 py-12 mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">


            <!-- Button to toggle filters on small screens -->
            <div class="lg:hidden mb-4">
                <button onclick="toggleFiltersVisibility()" id="toggleFilters"
                    class="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2">
                    Show Filters
                </button>
            </div>


            <!-- Sidebar Filters -->
            <aside id="aside-filters"
                class="bg-white p-6 rounded-2xl shadow-md space-y-6 max-w-sm hidden lg:block transition duration-300">
                <h2 class="text-xl font-semibold text-gray-800">Filters</h2>

                <form id="filterForm" method="GET" action="<?php echo e(route('products.index')); ?>">
                    <!-- Categories -->
                    <div class="mb-6">
                        <h3 class="font-medium text-gray-700 mb-3">Categories</h3>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>"
                                    class="text-teal-600 rounded focus:ring-teal-500" <?php echo e(is_array(request('categories'))
                                    && in_array($category->id, request('categories')) ? 'checked' : ''); ?>>
                                <span class="text-sm text-gray-600"><?php echo e($category->name); ?></span>
                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Brands -->
                    <div class="mb-6">
                        <h3 class="font-medium text-gray-700 mb-3">Brands</h3>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" name="brands[]" value="<?php echo e($brand->id); ?>"
                                    class="text-teal-600 rounded focus:ring-teal-500" <?php echo e(is_array(request('brands')) &&
                                    in_array($brand->id, request('brands')) ? 'checked' : ''); ?>>
                                <span class="text-sm text-gray-600"><?php echo e($brand->name); ?></span>
                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Max Price -->
                    <div class="mb-6">
                        <h3 class="font-medium text-gray-700 mb-3">Max Price</h3>
                        <div class="space-y-2">
                            <?php
                            $maxPrice = request('max_price', 2500);
                            ?>
                            <input type="range" name="max_price" min="0" max="5000" value="<?php echo e($maxPrice); ?>"
                                class="w-full accent-teal-600" id="priceRange">
                            <div class="flex justify-between text-xs text-gray-500">
                                <span>$0</span>
                                <span id="priceValue" class="font-medium text-teal-600">$<?php echo e(number_format($maxPrice)); ?></span>
                                <span>$5,000</span>
                            </div>
                        </div>
                    </div>

                    <!-- Condition -->
                    <div class="mb-6">
                        <h3 class="font-medium text-gray-700 mb-3">Condition</h3>
                        <select name="condition"
                            class="w-full border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500">
                            <option value="" <?php echo e(request('condition')=='' ? 'selected' : ''); ?>>All Conditions</option>
                            <option value="new" <?php echo e(request('condition')=='new' ? 'selected' : ''); ?>>New</option>
                            <option value="used" <?php echo e(request('condition')=='used' ? 'selected' : ''); ?>>Used</option>
                            <option value="refurbished" <?php echo e(request('condition')=='refurbished' ? 'selected' : ''); ?>>
                                Refurbished</option>
                        </select>
                    </div>

                    <!-- In Stock -->
                    <div class="mb-6">
                        <label class="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" name="in_stock" value="1"
                                class="text-teal-600 rounded focus:ring-teal-500" <?php echo e(request('in_stock')=='1'
                                ? 'checked' : ''); ?>>
                            <span class="text-sm text-gray-700">In Stock Only</span>
                        </label>
                    </div>

                    <!-- Buttons -->
                    <div class="space-y-3">
                        <button type="submit"
                            class="w-full bg-teal-600 hover:bg-teal-700 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2">
                            Apply Filters
                        </button>
                        <button type="button" id="clearFilters"
                            class="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-3 px-4 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2">
                            Clear All
                        </button>
                    </div>
                </form>
            </aside>




            <!-- Product Grid -->
            <div class="md:col-span-3">

                <div
                    class="py-6 px-6 bg-gradient-to-r from-orange-600 to-teal-600 rounded-xl shadow-lg text-white text-center">
                    <h1 class="text-2xl font-extrabold tracking-tight truncate max-w-full mx-auto"
                        title="<?php echo e($filterName ?? 'All Products'); ?>">
                        <?php echo e(Str::limit($filterName ?? 'All Products', 80, '...')); ?>

                    </h1>

                    <?php if(request()->has('q') || request()->has('categories') || request()->has('brands')): ?>
                    <p class="mt-1 text-sm text-orange-100">
                        Showing filtered results based on your selection.
                    </p>
                    <?php endif; ?>
                </div>



                <div class="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8" id="products-grid">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $filterClass = strtolower(str_replace(' ', '-', $product->category->name ?? 'all'));

                    $price = $product->sale_price ?? $product->price;
                    $hasSale = !is_null($product->sale_price) && $product->sale_price < $product->price;
                        $delay = 200 + ($index * 50);
                        $discount = $hasSale ? round((($product->price - $product->sale_price) / $product->price) * 100)
                        : 0;
                        $rating = $product->average_rating ?? 4.5;
                        $reviewCount = $product->reviews_count ?? rand(50, 200);
                        ?>

                        <div class="product-card <?php echo e($filterClass); ?> bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:scale-105 group relative border border-gray-100"
                            data-aos="fade-up" data-aos-delay="<?php echo e($delay); ?>" data-price="<?php echo e($price); ?>"
                            data-name="<?php echo e($product->name); ?>" data-created="<?php echo e($product->created_at); ?>">

                            <!-- Image -->
                            <div class="relative overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100">
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="block">
                                    <img src="<?php echo e(Storage::url($product->image_path)); ?>" alt="<?php echo e($product->name); ?>"
                                        class="w-full h-64 object-contain p-4 group-hover:scale-110 transition-transform duration-500"
                                        loading="lazy">
                                </a>

                                <?php if($hasSale): ?>
                                <div class="absolute top-4 left-4 z-10">
                                    <div
                                        class="bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-2 rounded-full text-sm font-bold shadow-lg">
                                        <i class="fas fa-percent mr-1"></i> <?php echo e($discount); ?>% OFF
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if($product->is_featured || $index < 3): ?> <div
                                    class="absolute <?php echo e($hasSale ? 'top-16' : 'top-4'); ?> left-4 z-10">
                                    <div
                                        class="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-2 rounded-full text-xs font-bold shadow-lg animate-pulse">
                                        🔥 HOT
                                    </div>
                            </div>
                            <?php endif; ?>

                            <?php if($product->stock <= 5 && $product->stock > 0): ?>
                                <div class="absolute bottom-4 left-4 z-10">
                                    <div class="bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                                        Only <?php echo e($product->stock); ?> left!
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Hover actions -->
                                <div
                                    class="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                                    <div class="flex space-x-3">
                                        <button onclick="toggleWishlist(<?php echo e($product->id); ?>)"
                                            class="bg-white text-gray-800 p-3 rounded-full hover:bg-red-50 hover:text-red-500 transition-all transform hover:scale-110 shadow-lg">
                                            <i class="fas fa-heart"></i>
                                        </button>
                                        <button onclick="quickAddToCart(<?php echo e($product->id); ?>)"
                                            class="bg-orange-600 text-white p-3 rounded-full hover:bg-orange-700 transition-all transform hover:scale-110 shadow-lg">
                                            <i class="fas fa-shopping-cart"></i>
                                        </button>
                                    </div>
                                </div>
                        </div>

                        <!-- Info -->
                        <div class="p-6 space-y-4">
                            <!-- Rating -->
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-2">
                                    <div class="flex text-yellow-400 text-sm">
                                        <?php for($i = 1; $i <= 5; $i++): ?> <i
                                            class="fas fa-star <?php echo e($i <= $rating ? '' : 'text-gray-300'); ?>"></i>
                                            <?php endfor; ?>
                                    </div>
                                    <span class="text-gray-500 text-sm">(<?php echo e($reviewCount); ?> Reviews)</span>
                                </div>
                            </div>

                            <!-- Title -->
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="block">
                                <h3
                                    class="text-xl font-bold text-gray-900 mb-2 hover:text-teal-600 transition-colors line-clamp-2">
                                    <?php echo e($product->name); ?>

                                </h3>
                            </a>

                            <!-- Description -->
                            <p class="text-gray-600 text-sm line-clamp-2 leading-relaxed">
                                <?php echo e(Str::limit($product->description, 80)); ?>

                            </p>

                            <!-- Price -->
                            <div class="flex items-center justify-between pt-2 border-t border-gray-100">
                                <div class="flex items-baseline space-x-2">
                                    <span class="text-2xl font-bold text-teal-600">$<?php echo e(number_format($price, 2)); ?>

                                    </span>

                                </div>
                                <div
                                    class="text-sm font-semibold <?php echo e($product->stock > 0 ? 'text-green-600' : 'text-red-600'); ?>">
                                    <i
                                        class="fas <?php echo e($product->stock > 0 ? 'fa-check-circle' : 'fa-times-circle'); ?> mr-1"></i>
                                    <?php echo e($product->stock > 0 ? 'In Stock' : 'Out of Stock'); ?>

                                </div>
                            </div>

                            <!-- Actions -->
                            <div class="flex space-x-2 pt-2">
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>"
                                    class="flex-1 bg-orange-600 text-white py-3 px-4 rounded-xl font-semibold text-center hover:bg-orange-700 transition-all transform hover:scale-105 shadow-md">
                                    View Details
                                </a>
                                <?php if($product->stock > 0): ?>
                                <button onclick="quickAddToCart(<?php echo e($product->id); ?>)"
                                    class="px-4 py-3 border-2 border-orange-600 text-orange-600 rounded-xl hover:bg-orange-600 hover:text-white transition-all transform hover:scale-105">
                                    <i class="fas fa-plus"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination (if needed) -->
            <div class="mt-10">
                <?php echo e($products->links()); ?>

            </div>
        </div>
        </div>
    </section>



    <?php $__env->startPush('scripts'); ?>

    <script>
        function toggleFiltersVisibility() {
        const filters = document.getElementById('aside-filters');
        const toggleButton = document.getElementById('toggleFilters');

        const isHidden = filters.classList.contains('hidden');

        filters.classList.toggle('hidden');
        toggleButton.textContent = isHidden ? 'Hide Filters' : 'Show Filters';
    }
    </script>


    <script>
        const priceRange = document.getElementById('priceRange');
            const priceValue = document.getElementById('priceValue');
            const clearBtn = document.getElementById('clearFilters');

            // Update price value display live
            priceRange.addEventListener('input', () => {
                priceValue.textContent = `$${parseInt(priceRange.value).toLocaleString()}`;
            });

            // Clear filters button resets form and reloads page without query params
            clearBtn.addEventListener('click', () => {
                document.getElementById('filterForm').reset();
                window.location.href = "<?php echo e(route('products.index')); ?>";
            });
    </script>


    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $attributes = $__attributesOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__attributesOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62f0572da10cb2e009b2958870a997e5)): ?>
<?php $component = $__componentOriginal62f0572da10cb2e009b2958870a997e5; ?>
<?php unset($__componentOriginal62f0572da10cb2e009b2958870a997e5); ?>
<?php endif; ?><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/products/index.blade.php ENDPATH**/ ?>