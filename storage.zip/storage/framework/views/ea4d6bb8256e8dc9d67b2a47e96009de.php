<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" <?php echo e($attributes); ?> fill="#f97316" width="40" height="40">
    <path d="M13 2L3 14h7v8l10-12h-7z" />
</svg><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>