<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
    <div class="flex h-full w-full flex-1 flex-col gap-6 rounded-xl p-4">

        <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-4">Product Details: <?php echo e($product->name); ?></h2>

        <div class="bg-white dark:bg-neutral-800 overflow-hidden shadow-sm sm:rounded-lg p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Product Name</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->name); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Product ID</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->id); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Model</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->model ?? 'N/A'); ?>

                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Price</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">AUD$<?php echo e(number_format($product->price, 2)); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Sale Price</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                        <?php if($product->sale_price): ?>
                        AUD$<?php echo e(number_format($product->sale_price, 2)); ?>

                        <span class="text-xs text-green-600 dark:text-green-400 ml-2">(<?php echo e(number_format((($product->price - $product->sale_price) / $product->price) * 100, 0)); ?>%
                            off)</span>
                        <?php else: ?>
                        N/A
                        <?php endif; ?>
                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Stock Quantity</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e(number_format($product->stock)); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Featured Product</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                        <span
                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($product->is_featured ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'); ?>">
                            <?php echo e($product->is_featured ? 'Yes' : 'No'); ?>

                        </span>
                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Category</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                        <?php echo e($product->category->name ?? 'N/A'); ?> 
                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Brand</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                        <?php echo e($product->brand->name ?? 'N/A'); ?> 
                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Condition</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->condition ?? 'N/A'); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Color</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->color ?? 'N/A'); ?>

                    </p>
                </div>

                
                <div class="md:col-span-2">
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Slug</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->slug); ?></p>
                </div>

                
                <div class="md:col-span-2">
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Description</p>
                    <p class="mt-1 text-gray-700 dark:text-gray-300 leading-relaxed"><?php echo e($product->description); ?></p>
                </div>

                
                <?php if($product->specifications): ?>
                <div class="md:col-span-2">
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Specifications</p>
                    <ul class="mt-1 text-gray-700 dark:text-gray-300 list-disc list-inside">
                        <?php $__currentLoopData = json_decode($product->specifications, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</strong> <?php echo e($value); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                
                <?php if($product->features): ?>
                <div class="md:col-span-2">
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Features</p>
                    <ul class="mt-1 text-gray-700 dark:text-gray-300 list-disc list-inside">
                        <?php $__currentLoopData = json_decode($product->features, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($feature); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                
                <div class="md:col-span-2">
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Product Image</p>
                    <?php if($product->image_path): ?>
                    <img src="<?php echo e(Storage::url($product->image_path)); ?>" alt="<?php echo e($product->name); ?> Image"
                        class="max-w-xs h-auto rounded-md shadow-md border border-gray-200 dark:border-neutral-700">
                    <?php else: ?>
                    <p class="text-gray-600 dark:text-gray-400">No main image uploaded for this product.</p>
                    <?php endif; ?>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Added By</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                        <?php echo e($product->addedBy->name ?? 'N/A'); ?> 
                    </p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Created At</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->created_at->format('M d, Y H:i A')); ?></p>
                </div>

                
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Last Updated</p>
                    <p class="mt-1 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($product->updated_at->format('M d, Y H:i A')); ?></p>
                </div>
            </div>

            <div class="flex items-center justify-end mt-6 pt-6 border-t border-gray-200 dark:border-neutral-700 gap-4">
                
                <a href="<?php echo e(route('admin.products.index')); ?>"
                    class="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200">
                    Back to Products
                </a>

                
                <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
                    class="inline-flex items-center px-4 py-2 bg-orange-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-orange-700 active:bg-orange-900 focus:outline-none focus:border-orange-900 focus:ring ring-orange-300 disabled:opacity-25 transition ease-in-out duration-150">
                    Edit Product
                </a>

                
                <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST"
                    onsubmit="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                        class="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-700 active:bg-red-900 focus:outline-none focus:border-red-900 focus:ring ring-red-300 disabled:opacity-25 transition ease-in-out duration-150">
                        Delete Product
                    </button>
                </form>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH F:\Projects\Laravel12\kamarona-electronics\resources\views/admin/products/show.blade.php ENDPATH**/ ?>